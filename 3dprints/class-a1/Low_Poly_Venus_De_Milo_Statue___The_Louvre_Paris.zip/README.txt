                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2776156
Low Poly Venus De Milo Statue / The Louvre, Paris by AndrewSink is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

Check out my [Amazon Page](http://amzn.to/2HpvB8i) to see what kind of gear I use to make these models!

This is a remix of ['Venus de Milo at The Louvre, Paris'](https://www.myminifactory.com/object/venus-de-milo-at-louvre-paris-1657), found on [MyMiniFactory](https://www.myminifactory.com) 

I used Blender to create a Low-Poly version of this model by reducing the number of faces and creating a flat bottom. 

Printed on a [Lulzbot Taz 6](http://amzn.to/2DLfdxC) using [Polylite PLA](http://amzn.to/2EjZnep) filament, and painted with [Rust-Oleum Filler Primer](http://amzn.to/2FBKeVa).

# Go Low Poly!

![Alt text](https://thingiverse-production-new.s3.amazonaws.com/private/89/f7/c4/aa/09/Venus_Bust.gif?AWSAccessKeyId=AKIAJAD3JQAWELLR63KQ&Expires=1517579730&Signature=fU9bjKN7WxPRPQegL6tMIwNroKE%3D)