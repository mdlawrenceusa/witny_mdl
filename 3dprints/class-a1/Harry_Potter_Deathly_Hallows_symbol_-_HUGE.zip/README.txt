                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3174484
Harry Potter Deathly Hallows symbol - HUGE by RazorWing is licensed under the Creative Commons - Public Domain Dedication license.
http://creativecommons.org/publicdomain/zero/1.0/

# Summary

My wife wanted a Deathly Hallows symbol to hang on the wall to go along with my others, so here it is! This is HUGE and will not be able to print without scaling. I suggest scaling the entire thing down to the size of your print bed or whatever size you want it, then scale the Z back up to be at least a 3-4mm tall for maximum effect!

I will post my printed one that is just shy of 1' (300mm) tall.

# Print Settings

Printer Brand: Creality
Printer: CR-10S
Rafts: Doesn't Matter
Supports: No
Resolution: .3
Infill: 15

Notes: 
3 top and bottom layers. You can do 2 for the backside, but supports will show through. 2 or 3 walls, doesn't matter.

I used a .6 nozzle even on this and it printed in about 2 hours.